README.txt
===========================
Name: Dhruv Rana
Class: CSIT313_01FA23
Professor: Professor Robila
Date: 09/26/2023
===========================
Description: This is the README file for HW2 Question 4. The purpose of 
the assignment was to better understand counting loops by 
performing matrix multiplication using counting loops as well as performing
matrix multiplication using logical loops.

Please read this file is to understand what files the zip folder 
'CSIT313HW2Rana.zip' holds and the purpose and functions of each file.
---------------------------
This zip folder contains two C code files titled 'countingloops.c' and
'logicalloops.c'.

The file 'countingloops.c' multiplies two hardcoded 4 by 4 matrices using 
counting loops, for-loops, and prints the resulting matrix. The file 'logicalloops.c' 
multiplies two 4 by 4 matrices logical loops, while-loops, and prints 
the reulting matrix.
---------------------------
Running the files:
1) You can use an online C compiler or IDE like Replit to run the files
2) If you are using a Unix shell, make sure to 
   change permissions (using Chmod 4755 'filename'), if needed, 
   so that you can compile and run the files. 
3) Run the files.
4) Both files will print three matrices, Matrix A and Matrix B,
   and the product, Matrix C.
5) After printing the matrices, the program will end. 
===========================

